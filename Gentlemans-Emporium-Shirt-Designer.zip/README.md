# Gentleman's Emporium — Gömlek Tasarım Stüdyosu

Türkçe, mobil uyumlu özel gömlek tasarım prototipi. Kumaş, renk, yaka, manşet, kol, etek, cep, düğme ve monogram seçenekleri interaktif 2D gömlek çizimini günceller. Tasarım bu cihazdaki tarayıcı depolamasına kaydedilir.

## Çalıştırma

`index.html` dosyasını bir statik web sunucusuyla açın. Örneğin:

```bash
python3 -m http.server 8000
```

Ardından `http://localhost:8000` adresini açın. Derleme veya paket kurulumu gerekmez.

## Kaynaklar ve kapsam

- Kumaş türü ve koleksiyon adları [Gentleman's Emporium kumaş kataloğundan](https://gentsemporium.com.tr/en/pages/kumaslar) alınmıştır.
- Ürün ve kumaş fotoğrafları marka tarafından paylaşılan Google Drive klasöründen seçilmiştir. `assets/` içindeki WebP dosyaları yayın için küçültülmüş kopyalardır.
- Fotoğraflar her tasarım kombinasyonunun gerçek üretim görüntüsü değildir. 2D çizim bir önizlemedir. Fotoğraf dosyaları koleksiyon kodlarıyla eşlenmediğinden renk örnekleri belirli kumaş koleksiyonunun doğrulanmış ürünü olarak sunulmaz.
- Fiyat, stok, ölçü toplama, ödeme ve mağazanın sepet bağlantısı bu prototipte bulunmaz. Kaydetme işlemi yalnızca yerel tarayıcı depolamasını kullanır.

Bu depo, marka görsellerini içerdiği için özel erişimle tutulmalıdır. Görsellerin kullanım hakları Gentleman’s Emporium tarafından yönetilir.
